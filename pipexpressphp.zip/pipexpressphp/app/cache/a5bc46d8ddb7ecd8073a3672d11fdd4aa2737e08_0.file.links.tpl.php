<?php
/* Smarty version 3.1.30, created on 2017-05-20 14:49:36
  from "/Users/yesuserahailu/NetBeansProjects/pipexpressphp/templates/links.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59208fc04d30a2_95583882',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a5bc46d8ddb7ecd8073a3672d11fdd4aa2737e08' => 
    array (
      0 => '/Users/yesuserahailu/NetBeansProjects/pipexpressphp/templates/links.tpl',
      1 => 1495306174,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59208fc04d30a2_95583882 (Smarty_Internal_Template $_smarty_tpl) {
?>


<li><a class="navbar-brand" href="index.php">Home</a></li>
<li><a href="about.php">About</a></li>
<li><a href="products.php">Products</a></li>
<?php }
}
