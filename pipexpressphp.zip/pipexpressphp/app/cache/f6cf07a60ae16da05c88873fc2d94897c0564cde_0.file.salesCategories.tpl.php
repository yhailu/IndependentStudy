<?php
/* Smarty version 3.1.30, created on 2017-05-21 14:23:19
  from "/Users/yesuserahailu/NetBeansProjects/pipexpressphp/templates/salesCategories.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5921db17084d43_01138638',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f6cf07a60ae16da05c88873fc2d94897c0564cde' => 
    array (
      0 => '/Users/yesuserahailu/NetBeansProjects/pipexpressphp/templates/salesCategories.tpl',
      1 => 1495390994,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:layout.tpl' => 1,
  ),
),false)) {
function content_5921db17084d43_01138638 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_293601285921db170705d5_57528133', "localstyle");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6169079805921db1707be91_64835257', "content");
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block "localstyle"} */
class Block_293601285921db170705d5_57528133 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  <style type="text/css">
    .top { 
      margin-bottom: 20px; 
    }
    .top h2 { 
      display: inline-block;
      margin: 0 30px 0 0;
      vertical-align: bottom;
    }
    .top form {
      display: inline-block;
      vertical-align: bottom;
    }
  </style>
<?php
}
}
/* {/block "localstyle"} */
/* {block "content"} */
class Block_6169079805921db1707be91_64835257 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="container">
<div class="row category-child" style="margin-top:20px">

        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="subPipe.php">
                
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Pipes</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="subFlexibleTubingAndHose.php">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Flexible Tubing and Hose</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="subFittings.php">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Fittings</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="subValves.php">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Valves</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="showProduct.php?field=010">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Tanks</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="showProduct.php?field=012">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Geotextiles</span>
                    </div>
                </div>
            </a>
    </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="subDrainage.php">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Drainage Products</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="showProduct.php?field=039">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Adhesives/Coatings</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="subAccessories.php">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Accessories</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="showProduct.php?field=054">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Pumps</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="showProduct.php?field=060">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Sheet, Rod, & Bar Stock</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="showProduct.php?field=063">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>ABS DWV Pipe & Fittings</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="showProduct.php?field=065">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>Black and Galvanized Pipe & Fittings</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-6 thumb">
            <a class="thumbnail" href="showProduct.php?field=066">
                <img class="img-responsive" src="" alt="">
                <div class="wrapper">
                    <div class="caption post-content">
                        <span>CPVC Fire Sprinkler Pipe & Fittings</span>
                    </div>
                </div>
            </a>
        </div>
</div>
</div>

<?php
}
}
/* {/block "content"} */
}
